package exam0204.method;

public class MethodCallExam {
	public static void main(String[] args) {
		
	}
}

class MyMath{
	public static double random() {
		return Math.random();
	}
	
}

class MyInteger{
	public static int parseInt(String par) {
		return Integer.parseInt(par);
	}
}